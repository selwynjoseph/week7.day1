package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import base.BaseClass;

public class ViewLeadPage3 extends BaseClass {

	public ViewLeadPage3(ChromeDriver driver) {
		this.driver=driver;
	}
	
public ViewLeadPage3 verifyViewLeadPage() {
		
		boolean displayed1=driver.findElement(By.xpath("//div[text()='View Lead']")).isDisplayed();
		Assert.assertTrue(displayed1);
		return this;
	}
}
