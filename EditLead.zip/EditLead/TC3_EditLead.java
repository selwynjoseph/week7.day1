package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class TC3_EditLead extends BaseClass {
	
	
	@BeforeTest
	public void setValue() {
		excelFileName="EditLead";

	}
	
	
	@Test(dataProvider="provideData")
	public void runEditLead(String username, String password, String phonenumber, String updatecompname) throws InterruptedException {
		
		LoginPage lp=new LoginPage(driver);
		lp.enterUserName(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCrmSfaLink()
		.clickLeadsButton()
		.clickFindLeadsButton()
		.clickPhoneButton()
		.enterPhoneNumber(phonenumber)
		.clickFindLeadsButton2()
		.clickFirstLeadDisplayed()
		.clickEditButton()
		.updateCompanyName(updatecompname)
		.clickUpdateButton()
		.verifyViewLeadPage();
		}
	

}
