package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class FindLeadsPage extends BaseClass{
	
	public FindLeadsPage(ChromeDriver driver) {
		this.driver=driver;
	}

	public FindLeadsPage clickPhoneButton() {
		driver.findElement(By.xpath("//span[text()='Phone']")).click();
		return this;

	}
	
	public FindLeadsPage enterPhoneNumber(String phno) {
		driver.findElement(By.xpath("//input[@name='phoneNumber']")).sendKeys(phno);
		return this;

	}
	
	public FindLeadsPage clickFindLeadsButton2() throws InterruptedException {
		driver.findElement(By.xpath("//button[text()='Find Leads']")).click();
		Thread.sleep(2000);
		return this;

	}
	
	public ViewLeadPage_2 clickFirstLeadDisplayed() {
		driver.findElement(By.xpath("//div[@class='x-grid3-cell-inner x-grid3-col-partyId']/a")).click();
		return new ViewLeadPage_2(driver);
		

	}
}
