package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class ViewLeadPage_2 extends BaseClass{
	
	public ViewLeadPage_2(ChromeDriver driver) {
		this.driver=driver;
	}

	public EditLeadPage clickEditButton() {
		driver.findElement(By.linkText("Edit")).click();
		return new EditLeadPage(driver);

	}
	
	
}
